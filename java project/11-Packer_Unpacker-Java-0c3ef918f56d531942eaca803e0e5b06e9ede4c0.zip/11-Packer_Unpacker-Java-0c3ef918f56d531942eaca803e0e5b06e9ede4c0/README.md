# Packer_Unpacker-Java
- This project is used to perform packing and unpacking activity for multiple types of files. 
- In case of Packing activity me maintain one file which contains metadata and data of multiple files from specified directory. 
- In case of Unpacking activity we extract all data from packed files and according to its metadata we create all files. 
- In this project we have to use Java as Front end as well as Backend for platform independency

Run above code as following steps

step 1 :- for compaling project type following commnd in your command prompt

javac login.java
step 2 :- for run project type following command

java login
step 3 : enter username & password as follow

username:abcd password:abcd
