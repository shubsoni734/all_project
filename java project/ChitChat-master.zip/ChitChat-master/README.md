# ChitChat
A simple group chat Application using Java Socket Programming. A simple GUI demonstration on localhost is shown below... This can be implemented over LAN connected machines by using their IP Address.. #socket #socketProgramming #chat #javaprogramminglanguage #groupchat
To watch how it is implemented click the link below:
 
https://www.linkedin.com/posts/deysarkarswarup_socket-socketprogramming-chat-activity-6581552689602236416-vMxm
