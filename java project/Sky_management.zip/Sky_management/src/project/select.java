/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.sql.*;
import javax.swing.JOptionPane;

/**
 *
 * @author hp
 */
public class select {
        public static ResultSet getData(String Query) {
        java.sql.Connection cn = null;
        Statement ste = null;
        ResultSet rs = null;
        try {
            cn = ConnectionProvider.getCon();
            ste = cn.createStatement();
            rs=ste.executeQuery(Query);
            return rs;
        } 
        catch (Exception e) 
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
}
